"""Magic: The Gathering Buylist Aggregator

A tool to aggregate Magic: The Gathering buylist prices from various online retailers.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com" 